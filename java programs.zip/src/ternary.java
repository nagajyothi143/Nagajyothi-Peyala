package ternary;

public class ternary {

	public static void main(String[] args) {
		int number = 10;
		String msg = (number % 2 == 0) ? "The number is even!" : "The number is odd!";
		System.out.println(msg);

	}

}
